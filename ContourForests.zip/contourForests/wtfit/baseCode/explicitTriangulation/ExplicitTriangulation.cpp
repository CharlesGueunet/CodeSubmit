#include                  <ExplicitTriangulation.h>

ExplicitTriangulation::ExplicitTriangulation(){

  vertexNumber_ = 0;
  pointSet_ = NULL;
  
  cellNumber_ = 0;
  cellArray_ = NULL;
}

ExplicitTriangulation::~ExplicitTriangulation(){

}
