#include                  <Triangulation.h>

Triangulation::Triangulation(){

  debugLevel_ = 0;
}

Triangulation::~Triangulation(){
  
}

